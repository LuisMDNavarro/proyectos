use bdhoteles; 
create table if not exists booking (
  dateTo date not null,
  dateFrom date not null,
  guestNo int not null,
  roomNo int not null,
    foreign key (guestNo)
    references guest (guestNo)
    on delete cascade,
    foreign key (roomNo)
    references room (roomNo)
    on delete cascade
    );
create table if not exists room (
  roomNo int primary key not null,
  `type` varchar(45) not null,
  price int not null,
  hotelNo int not null,
    foreign key (hotelNo)
    references hotel (hotelNo)
    on delete cascade
    );

insert into hotel(hotelNo, hotelName, city)
VALUES('1', 'Hotel sicaru', 'Puebla'),
      ('2', 'Hotel Estrella de Mar', 'Veracruz'),
      ('3', 'Hotel Bolillos', 'CDMX'),
      ('4', 'Hotel Aloft', 'Cancun'),
      ('5', 'Hotel las Nubes', 'Tlaxcala');

insert into room(roomNo, `type`, price, hotelNo)
VALUES('11', 'sencillo', '2500', '1'), ('12', 'sencillo', '2500', '1'), ('20', 'doble', '5300', '1'), ('21', 'doble', '5300', '1'), ('30', 'VIP', '7500', '1'),
      ('1', 'sencillo', '3800', '2'), ('2', 'sencillo', '3800', '2'), ('14', 'doble', '7500', '2'), ('15', 'doble', '7500', '2'), ('19', 'VIP', '9500', '2'),
      ('16', 'sencillo', '1500', '3'), ('17', 'sencillo', '1500', '3'), ('28', 'doble', '3000', '3'), ('29', 'doble', '3000', '3'), ('35', 'VIP', '6000', '3'),
      ('5', 'sencillo', '6500', '4'), ('6', 'sencillo', '6500', '4'), ('31', 'doble', '13300', '4'), ('32', 'doble', '13300', '4'), ('40', 'VIP', '20500', '4'),
      ('3', 'sencillo', '500', '5'), ('4', 'sencillo', '500', '5'), ('9', 'doble', '1000', '5'), ('10', 'doble', '1000', '5'), ('18', 'VIP', '2500', '5');

insert into guest(guestNo, guestName, guestAddress)
VALUES('1', 'Jorge', '3 sur #1'), 
 ('2', 'Enrique', '9 oeste #16'),
 ('3', 'Maria', '8 norte #7'),
 ('4', 'Pablo', '18 este #9'),
 ('5', 'Axel', '1 sur #5');
Update guest set guestName='Pablo' where guestNo=4;
insert into booking(guestNo, roomNo, dateTo, dateFrom)
VALUES('1', '11', '2000-11-01', '2000-11-01'), ('1', '6', '2000-11-02', '2000-11-02'), ('1', '20', '2000-11-03', '2000-11-03'), ('1', '29', '2000-11-04', '2000-11-04'), ('1', '18', '2000-11-05', '2000-11-05'),
('1', '3', '2000-11-06', '2000-11-06'), ('1', '4', '2000-11-07', '2000-11-07'), ('1', '1', '2000-11-08', '2000-11-08'), ('1', '31', '2000-11-09', '2000-11-09'), ('1', '10', '2000-11-10', '2000-11-10'),
('2', '2', '2000-12-20', '2000-12-20'), ('2', '1', '2000-12-21', '2000-12-21'), ('2', '4', '2000-12-22', '2000-12-22'), ('2', '28', '2000-12-23', '2000-12-23'), ('2', '10', '2000-12-24', '2000-12-24'), 
('2', '16', '2000-12-25', '2000-12-25'), ('2', '17', '2000-12-26', '2000-12-26'), ('2', '12', '2000-12-27', '2000-12-27'), ('2', '29', '2000-12-28', '2000-12-28'), ('2', '35', '2000-12-29', '2000-12-29'),
('3', '4', '2006-02-05', '2006-02-05'), ('3', '40', '2006-02-06', '2006-02-06'), ('3', '32', '2006-02-07', '2006-02-07'), ('3', '16', '2006-02-08', '2006-02-08'), ('3', '9', '2006-02-09', '2006-02-09'), 
('3', '6', '2006-02-10', '2006-02-10'), ('3', '11', '2006-02-11', '2006-02-11'), ('3', '14', '2006-02-12', '2006-02-12'), ('3', '30', '2006-02-13', '2006-02-13'), ('3', '1', '2006-02-14', '2006-02-14'),
('4', '28', '2003-06-17', '2003-06-17'), ('4', '20', '2003-06-18', '2003-06-18'), ('4', '4', '2003-06-19', '2003-06-19'), ('4', '30', '2003-06-20', '2003-06-20'), ('4', '31', '2003-06-21', '2003-06-21'),
('4', '3', '2003-06-22', '2003-06-22'), ('4', '35', '2003-06-23', '2003-06-23'), ('4', '2', '2003-06-24', '2003-06-24'), ('4', '17', '2003-06-25', '2003-06-25'), ('4', '40', '2003-06-26', '2003-06-26'),
('5', '1', '2012-09-15', '2012-09-15'), ('5', '2', '2012-09-16', '2012-09-16'), ('5', '3', '2012-09-17', '2012-09-17'), ('5', '4', '2012-09-18', '2012-09-18'), ('5', '5', '2012-09-19', '2012-09-19'),
('5', '6', '2012-09-20', '2012-09-20'), ('5', '9', '2012-09-21', '2012-09-21'), ('5', '10', '2012-09-22', '2012-09-22'), ('5', '11', '2012-09-23', '2012-09-23'), ('5', '12', '2012-09-24', '2012-09-24');

select h.hotelNo 'Numero del hotel', h.hotelName 'Nombre del hotel', r.roomNo 'Numero del cuarto',
r.type 'Tipo de cuarto', r.price 'Precio del cuarto', g.guestNo 'Numero del cliente', g.guestName 'Nombre del cliente',
g.guestAddress 'Direccion del cliente', b.dateTo 'Dia de llegada', b.dateFrom 'Dia de salida'
from hotel h inner join room r on h.hotelNo=r.hotelNo inner join booking b on r.roomNo=b.roomNo 
inner join guest g on g.guestNo=b.guestNo
where b.dateTo='2000-11-01' and b.dateFrom='2000-11-01';

select h.hotelName 'Nombre del hotel', sum(r.price) 'Total de ingresos'
from hotel h inner join room r on h.hotelNo=r.hotelNo inner join booking b on r.roomNo=b.roomNo
group by h.hotelName;

select g.guestName 'Nombre del huesped', sum(r.price) 'Total de ingresos'
from guest g inner join booking b on g.guestNo=b.guestNo inner join room r on r.roomNo=b.roomNo
group by g.guestName;

select r.roomNo 'Numero del cuarto', count(b.roomNo) 'Repeticiones'
from room r inner join booking b on r.roomNo=b.roomNo
group by r.roomNo order by Repeticiones desc limit 1;

update room r inner join booking b on r.roomNo=b.roomNo set price=price*2 
where dateTO like '%-12-%';
select * from booking b inner join room r on r.roomNo=b.roomNo
where dateTO like '%-12-%';

insert into guest(guestNo, guestName, guestAddress)
VALUES('6', 'Pedro', '53 norte #1053'), 
 ('7', 'Marco', '4 sur #1095');
 select g.guestNo, g.guestName, g.guestAddress, b.roomNo, b.dateTo, b.dateFrom 
 from guest g left join booking b on g.guestNo=b.guestNo
 where b.guestNo is null;
 
 insert into hotel(hotelNo, hotelName, city)
VALUES('6', 'Hotel Padua', 'Monterrey'),
      ('7', 'Hotel Estrella', 'Queretaro');
insert into room(roomNo, `type`, price, hotelNo)
VALUES('7', 'sencillo', '2500', '6'), ('8', 'sencillo', '2500', '6'), ('13', 'doble', '5300', '6'), ('22', 'doble', '5300', '6'), ('23', 'VIP', '7500', '6'),
      ('24', 'sencillo', '3800', '7'), ('25', 'sencillo', '3800', '7'), ('26', 'doble', '7500', '7'), ('27', 'doble', '7500', '7'), ('33', 'VIP', '9500', '7');
select h.hotelNo 'Numero del hotel', h.hotelName 'Nombre del hotel', r.roomNo 'Numero del cuarto',
r.type 'Tipo de cuarto', r.price 'Precio del cuarto'  
from hotel h inner join room r on h.hotelNo=r.hotelNo 
left join booking b on r.roomNo=b.roomNo
where b.roomNo is null;